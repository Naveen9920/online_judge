#include <iostream> 
      using namespace std;
      // Define the main function
      int main() { 
          // Declare variables
          int num1, num2, sum;
          // Prompt user for input
          cin >> num1 >> num2;  
          // Calculate the sum
          sum = num1 + num2;  
          // Output the result
          cout << "The sum of the two numbers is: " << sum;  
          // Return 0 to indicate successful execution
          return 0;  
      }