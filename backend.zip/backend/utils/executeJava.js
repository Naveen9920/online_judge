const { exec } = require("child_process");
const path = require("path");
const fs = require("fs");

const outputPath = path.join(__dirname, "outputs");

// Ensure output directory exists
if (!fs.existsSync(outputPath)) {
    fs.mkdirSync(outputPath, { recursive: true });
}

const executeJava = (filePath, inputPath) => {
    const dir = path.dirname(filePath);
    return new Promise((resolve, reject) => {
        const command = inputPath
            ? `javac ${filePath} && cd ${dir} && java Main < ${inputPath}` // Compile and execute with input
            : `javac ${filePath} && cd ${dir} && java Main`; // Compile and execute without input

        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject({ error: error.message, stderr });
            } else if (stderr) {
                reject({ error: stderr });
            } else {
                resolve(stdout.trim()); // Return output without extra spaces
            }
        });
    });
};

module.exports = {
    executeJava,
};
